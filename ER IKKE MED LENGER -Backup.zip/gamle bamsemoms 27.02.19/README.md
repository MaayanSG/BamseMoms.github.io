# BamseMoms Web Utvikling
<img src="images/logo.png" align="right" width="400" height="400" />
this site is in norweagian and not englsih

# Besøk Nettsiden
[BamseMoms.github.io/](https://BamseMoms.github.io/)

# Copyright
Copyright © 2019 BamseMoms - All rights reserved

Design & Development by BamseMoms


## License
[MIT](https://choosealicense.com/licenses/mit/)
